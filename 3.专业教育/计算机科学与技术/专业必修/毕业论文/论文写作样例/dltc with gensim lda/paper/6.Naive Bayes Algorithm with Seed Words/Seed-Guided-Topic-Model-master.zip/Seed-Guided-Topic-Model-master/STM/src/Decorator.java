
/**
 * Created by XJ on 2016/3/10.
 */
public interface Decorator {
    public SModel decorateSModel();
}
