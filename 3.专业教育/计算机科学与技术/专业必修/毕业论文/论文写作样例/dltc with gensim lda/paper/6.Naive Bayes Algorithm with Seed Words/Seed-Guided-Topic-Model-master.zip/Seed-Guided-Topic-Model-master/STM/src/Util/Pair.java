package Util;

/**
 * Created by XJ on 2015/11/7.
 */
public class Pair {
    public int word;
    public int topic;

    public Pair(int key, int value) {
        this.word = key;
        this.topic = value;
    }
}
